<?php
$pageTitle="The Studioware Project";
?>

<div class="left-col">
	<h2>About The Studioware Project</h2>
	<p>Studioware is a project aimed at providing build scripts and packages of the best open source music and audio editing software available for Slackware Linux.</p>
	<p style="text-align:left;">We also include libraries and other dependencies with a comprehensive dependency list for each package so you will know exactly what you need to install.</p>
	<p style="text-align:left;">Although Studioware is quite a small project, we are Slackware users of many years experience and intend to share our experiences of building and running the software on the wiki. Most of us are musicians too.</p>
</div>

<div class="right-col">
	<h2>Network</h2>
	<p style="text-align:left;">Apart from this website we also have an IRC channel and mailing list. Everyone is welcome to join #studioware on irc.freenode.net. The mailing list can be found here: <a href="http://groups.google.com/group/studioware">http://groups.google.com/group/studioware</a></p>
	<h2>Get Involved!</h2>
	<p style="text-align:left;">We want to hear about your experiences too. Any hints or tips or other useful things that you've discovered while building or running packages you'd like to share will be welcome.</p>
</div>
