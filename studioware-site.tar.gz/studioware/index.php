<?php
/**
 * index.php
 *
 * this is the main router file, it takes in parameters and builds
 * the final output that goes to the user.
 *
 * Certain values can be used throughout pages, some via PHP
 * and others that will be replaced in the final HTML.
 *
 * Replacements:
 * <!--TITLE--> - will be replaced with the PHP variable $pageTitle
 * <!--SITEURL--> - replaced with $siteURL
 *
 * PHP variables:
 * 
 * $pageTitle - what gets placed in the <title> tag.
 * $siteURL - the main url.
 *
 */

/** Initial setup **/
ob_start ();
error_reporting(E_ALL);
ini_set('display_errors', true);
ini_set('html_errors', false);
require_once('functions/dirfunctions.php');

/** Default values **/
$pageTitle = 'Studioware';
$siteURL = 'http://localhost/studioware';

/** Determine our navigation, view, and params **/
$request_uri = trim(str_replace(dirname($_SERVER['SCRIPT_NAME']), '', $_SERVER['REQUEST_URI']), '/');
$parts = explode('?', $request_uri, 2);
$navigation = array_shift($parts);
if (!empty($parts[0])) {
	$paramlist = explode('&', $parts[0]);
	foreach($paramlist as $param) {
		$parampart = explode('=', $param, 2);
		$params[$parampart[0]] = $parampart[1];
	}
}
unset($parts);

/** From the navigation, build the page.
 * First, determine the appropraite view
 */
$view = array_shift(explode('/', $navigation));
if (file_exists($view . '.php')) {
	$page = $view . '.php';
} else if (file_exists($navigation . '.php')) {
	$page = $navigation . '.php';
} else {
	// no 404 here, just the default.
	$page = 'default.php';
}

/** Build the page **/
// header includes the navigation for now.
require_once "header.php";
//require_once "navigation.php";
?>
<div id="content" class="clearfix">
<?php require_once $page; ?>
</div>
<?php
require_once "footer.php";

/** Actually do the output **/
$pageContents = ob_get_contents ();
ob_end_clean ();
echo str_replace(array('<!--TITLE-->', '<!--SITEURL-->'), array($pageTitle, $siteURL), $pageContents);
?>

