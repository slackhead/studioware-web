<?php
$pageTitle="Studioware Project Links";
?>

<div class="centre-col">

<p>
<a href="http://slackware.com" title="Slackware">http://slackware.com</a>
The homepage for Slackware Linux.<br />
</p>

<p>
<a href="http://slackbuilds.org" title="Slackbuilds">http://slackbuilds.org</a>
A large repo of slackbuild scripts.<br />
</p>

<p>
<a href="http://slackermedia.info" title="Slackermedia">http://slackermedia.info</a>
Slackermedia is documentation providing the information a user will need to create a full multimedia studio from a Slackware base install.<br />
</p>

<p>
<a href="http://opensourcemusician.com" title="OSM Wiki and Podcast">http://opensourcemusician.com</a>
The podcast covers the use of free libre and open source software for musicians. The show covers topics like software, gear, audio releases and recording.
</p>

</div>

