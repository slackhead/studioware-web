<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<title><!--TITLE--></title>

		<link href="<!--SITEURL-->/css/site.css" rel="stylesheet" type="text/css"/>
		<link rel="shortcut icon" href="favicon.ico"/>

		<meta name="description" content="Studioware - bringing audio to Slackware."/>
		<meta name="keywords" content="studioware,slackware,audio,sound,recording"/>
		<meta name="google-site-verification" content="iDXOFARwllMbvTCy5ZQBvZkl4TR6cvB_9FKzYLhtD_8" />

		<script type="text/javascript" src="<!--SITEURL-->/js/site.js"></script>
		<script type="text/javascript">

		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-8872411-9']);
		  _gaq.push(['_trackPageview']);

		  (function() {
		    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();

		</script>
	</head>
	<body>
		<a name="top">
		<div id="page"></a>
			<div id="header">
				<a href="<!--SITEURL-->"><img src="<!--SITEURL-->/images/studioware8.gif" alt="Studioware" /></a>
			</div>
			<div id="navigation">
				<ul class="menu">
					<li>
						<a title="Home" href="<!--SITEURL-->">Home</a>
					</li>
					<li>
						<a title="Latest News" href="<!--SITEURL-->/news">Latest News</a>
					</li>
					<li>
						<a title="Applications List" href="http://www.studioware.org/wiki/index.php?title=Application_List">Applications List</a>
					</li>
					<li>
						<a title="SlackBuilds" href="<!--SITEURL-->/slackbuilds">SlackBuilds</a>
					</li>
					<li>
						<a title="Packages" href="<!--SITEURL-->/packages">Packages</a>
					</li>
					<li>
						<a title="Studiopkg" href="<!--SITEURL-->/studiopkg">Studiopkg</a>
					</li>
					<li>
						<a title="Sepkg" href="<!--SITEURL-->/sepkg">Sepkg</a>
					</li>
					<li>
						<a title="Wiki" href="<!--SITEURL-->/wiki">Wiki</a>
					</li>
					<li>
						<a title="Links" href="<!--SITEURL-->/links">Links</a>
					</li>
				</ul>
			</div>

