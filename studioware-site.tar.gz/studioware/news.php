<?php
$pageTitle="Studioware Project News";
?>
<div class="centre-col">
	<ul class="newsfeed">
		<li>
			<h3>Added</h3>
			<p>Traverso<br />Audacity<br /></p>
			<span class="date">David, Thu 10 Nov 2011 19:01:02 GMT</span> 
		</li>
		<li>
			<h3>Added</h3>
			<p>Ardour<br />Hydrogen<br />Studiopkg and Sepkg<br /></p>
			<span class="date">David, Wed 07 Sep 2011 06:49:48 BST</span> 
		</li>
		<li>
			<h3>Some Ideas TBC</h3>
			<p>ardour + plugins<br />qtractor<br />
rakatrack<br />
				<br />
				Some sort of installer script similar to slackpkg/sbopkg with queue file support.<br />
			</p>
			<span class="date">David, Mon 25 Jul 2011 06:37:06 BST</span> 
		</li>
		<li>
			<h3>x86_64 Packages for 13.37</h3>
			<p>A bunch of 64 bit packages have been uploaded.</p>
			<span class="date">David, Tue 03 May 2011 15:10:20 BST</span> 
		</li>
		<li>
			<h3>SlackBuilds Available for 13.37</h3>
			<p>A bundle of slackbuilds have been uploaded, together with 32 bit packages.<br/>x86_64 packages to follow.</p>
			<span class="date">David, Tue 03 May 2011 05:23:52 BST</span> 
</li>
		<li>
			<h3>Mailing List Open</h3>
			<p>The mailing list is open! Thanks to dtanner aka slacktop. You can find it here: <br/><a href="http://groups.google.com/group/studioware">http://groups.google.com/group/studioware</a></p>
			<span class="date">David, Wed 20 Apr 2011 03:20:11 BST</span> 
		</li>
		<li>
			<h3>Website Under Way</h3>
			<p>Just begun working on the website tonight and now it's well under way.</p>
			<span class="date">David, Wed 20 Apr 2011 02:11:55 BST</span>
		</li>
	</ul>
</div>
