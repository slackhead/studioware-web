			<div id="footer">
				All content &copy; 2011 studioware.org<br />
				Slackware&reg; &copy; Patrick Volkerding<br />
				Linux&reg; &copy; Linus Torvalds<br />
			</div>
		</div> <!-- end div id="page" -->
	</body>
</html>
